/**
 * Define la lista de todos los degradados disponibles en la aplicación,
 * así como una paleta de colores por defecto para aquellos que no tienen una personalizada.
 */
// Colores por defecto para los degradados que no tienen una paleta personalizada.
// Puedes ajustar estos colores para que se adapten a la mayoría de los degradados.
export const DEFAULT_GRADIENT_COLORS = {
  '--text-color': '#e0e0e0',
  '--text-color-strong': '#ffffff',
  '--panel-bg': '#1c1c1c',
  '--accent-color': '#00aaff',
  '--button-bg': 'rgba(255, 255, 255, 0.07)',
  '--button-hover-bg': 'rgba(255, 255, 255, 0.12)'
};

// Lista de degradados.
// Los estilos modernos y con paleta integrada aparecen primero.
const gradientsData = [
    {
        "id": "esmeralda-abismo",
        "name": "Esmeralda Abismo",
        "gradient": "radial-gradient(circle at 82% 18%, rgba(16, 185, 129, 0.28) 0%, transparent 52%), radial-gradient(circle at 18% 85%, rgba(6, 95, 70, 0.35) 0%, transparent 55%), linear-gradient(135deg, #040b09 0%, #071915 55%, #030908 100%)",
        "cssVariables": {
            "--text-color": "#ecfdf5",
            "--text-secondary": "#6ee7b7",
            "--panel-bg": "#064e3b",
            "--accent-color": "#34d399"
        }
    },
    {
        "id": "aurora-nordica",
        "name": "Aurora Nórdica",
        "gradient": "radial-gradient(circle at 15% 20%, rgba(56, 189, 248, 0.26) 0%, transparent 50%), radial-gradient(circle at 85% 75%, rgba(52, 211, 153, 0.22) 0%, transparent 52%), linear-gradient(135deg, #0b132b 0%, #1c2541 52%, #0f292e 100%)",
        "cssVariables": {
            "--text-color": "#f0f9ff",
            "--text-secondary": "#7dd3fc",
            "--panel-bg": "#0f2438",
            "--accent-color": "#38bdf8"
        }
    },
    {
        "id": "nebulosa-amatista",
        "name": "Nebulosa Amatista",
        "gradient": "radial-gradient(circle at 80% 20%, rgba(192, 132, 252, 0.28) 0%, transparent 50%), radial-gradient(circle at 20% 80%, rgba(236, 72, 153, 0.2) 0%, transparent 50%), linear-gradient(135deg, #0b0716 0%, #1d1035 55%, #0c0818 100%)",
        "cssVariables": {
            "--text-color": "#faf5ff",
            "--text-secondary": "#d8b4fe",
            "--panel-bg": "#24113d",
            "--accent-color": "#c084fc"
        }
    },
    {
        "id": "obsidiana-dorada",
        "name": "Obsidiana Dorada",
        "gradient": "radial-gradient(circle at 75% 22%, rgba(251, 191, 36, 0.2) 0%, transparent 48%), linear-gradient(135deg, #0c0a09 0%, #1f1916 55%, #2b1808 100%)",
        "cssVariables": {
            "--text-color": "#fefce8",
            "--text-secondary": "#fcd34d",
            "--panel-bg": "#24190d",
            "--accent-color": "#fbbf24"
        }
    },
    {
        "id": "oceano-abisal",
        "name": "Océano Abisal",
        "gradient": "radial-gradient(circle at 20% 15%, rgba(34, 211, 238, 0.24) 0%, transparent 50%), linear-gradient(135deg, #040d1a 0%, #0a2540 55%, #06182c 100%)",
        "cssVariables": {
            "--text-color": "#ecfeff",
            "--text-secondary": "#67e8f9",
            "--panel-bg": "#072236",
            "--accent-color": "#22d3ee"
        }
    },
    {
        "id": "carmesi-nocturno",
        "name": "Carmesí Nocturno",
        "gradient": "radial-gradient(circle at 82% 20%, rgba(251, 113, 133, 0.24) 0%, transparent 50%), linear-gradient(135deg, #120509 0%, #3b0a1a 55%, #190814 100%)",
        "cssVariables": {
            "--text-color": "#fff1f2",
            "--text-secondary": "#fda4af",
            "--panel-bg": "#360c18",
            "--accent-color": "#fb7185"
        }
    },
    {
        "id": "bosque-bruma",
        "name": "Bosque en Bruma",
        "gradient": "linear-gradient(135deg, #071917 0%, #113831 50%, #1e293b 100%)",
        "cssVariables": {
            "--text-color": "#f0fdfa",
            "--text-secondary": "#5eead4",
            "--panel-bg": "#0f2e2b",
            "--accent-color": "#2dd4bf"
        }
    },
    {
        "id": "cyber-synthwave",
        "name": "Synthwave 2099",
        "gradient": "radial-gradient(circle at 18% 82%, rgba(56, 189, 248, 0.25) 0%, transparent 48%), linear-gradient(135deg, #140826 0%, #3b0764 52%, #701a75 100%)",
        "cssVariables": {
            "--text-color": "#fdf2f8",
            "--text-secondary": "#f9a8d4",
            "--panel-bg": "#2b0947",
            "--accent-color": "#f472b6"
        }
    },
    {
        "id": "cobalto-electrico",
        "name": "Cobalto Eléctrico",
        "gradient": "radial-gradient(circle at 80% 15%, rgba(96, 165, 250, 0.3) 0%, transparent 50%), linear-gradient(135deg, #050a1f 0%, #172554 55%, #1e3a8a 100%)",
        "cssVariables": {
            "--text-color": "#eff6ff",
            "--text-secondary": "#93c5fd",
            "--panel-bg": "#102152",
            "--accent-color": "#60a5fa"
        }
    },
    {
        "id": "ocaso-volcanico",
        "name": "Ocaso Volcánico",
        "gradient": "linear-gradient(135deg, #18080b 0%, #7c2d12 52%, #be123c 100%)",
        "cssVariables": {
            "--text-color": "#fff7ed",
            "--text-secondary": "#fdba74",
            "--panel-bg": "#45150e",
            "--accent-color": "#fb923c"
        }
    },
    {
        "id": "jade-cristal",
        "name": "Jade Cristal",
        "gradient": "linear-gradient(135deg, #042f2e 0%, #115e59 50%, #134e4a 100%)",
        "cssVariables": {
            "--text-color": "#f0fdfa",
            "--text-secondary": "#99f6e4",
            "--panel-bg": "#083d39",
            "--accent-color": "#5eead4"
        }
    },
    {
        "id": "prisma-nocturno",
        "name": "Prisma Nocturno",
        "gradient": "radial-gradient(circle at 15% 15%, rgba(99, 102, 241, 0.28) 0%, transparent 45%), radial-gradient(circle at 85% 20%, rgba(16, 185, 129, 0.22) 0%, transparent 45%), radial-gradient(circle at 50% 85%, rgba(236, 72, 153, 0.18) 0%, transparent 50%), linear-gradient(135deg, #090b14 0%, #111827 100%)",
        "cssVariables": {
            "--text-color": "#f1f5f9",
            "--text-secondary": "#a5b4fc",
            "--panel-bg": "#151a2e",
            "--accent-color": "#818cf8"
        }
    },
    {
        "id": "sakura-seda",
        "name": "Seda Sakura",
        "gradient": "linear-gradient(135deg, #2b1329 0%, #500724 50%, #1e1b2e 100%)",
        "cssVariables": {
            "--text-color": "#fdf2f8",
            "--text-secondary": "#fbcfe8",
            "--panel-bg": "#3b102c",
            "--accent-color": "#f9a8d4"
        }
    },
    {
        "id": "cosmos-profundo",
        "name": "Cosmos Profundo",
        "gradient": "radial-gradient(circle at 75% 25%, rgba(56, 189, 248, 0.22) 0%, transparent 48%), radial-gradient(circle at 25% 80%, rgba(129, 140, 248, 0.2) 0%, transparent 50%), linear-gradient(160deg, #020617 0%, #0f172a 100%)",
        "cssVariables": {
            "--text-color": "#f8fafc",
            "--text-secondary": "#93c5fd",
            "--panel-bg": "#0b1426",
            "--accent-color": "#38bdf8"
        }
    },
    {
        "id": "glaciar-polar",
        "name": "Glaciar Polar",
        "gradient": "linear-gradient(135deg, #e0f2fe 0%, #bae6fd 50%, #dbeafe 100%)",
        "cssVariables": {
            "--text-color": "#0f172a",
            "--text-secondary": "#334155",
            "--panel-bg": "#ffffff",
            "--accent-color": "#0284c7"
        }
    },
    {
        "id": "arena-dorada",
        "name": "Arena Cálida",
        "gradient": "linear-gradient(135deg, #fef3c7 0%, #fde68a 50%, #fed7aa 100%)",
        "cssVariables": {
            "--text-color": "#451a03",
            "--text-secondary": "#78350f",
            "--panel-bg": "#ffffff",
            "--accent-color": "#d97706"
        }
    },
    {
        "id": "aurora-mist",
        "name": "Aurora Mist (Modern)",
        "gradient": "linear-gradient(135deg, #00f2fe 0%, #4facfe 100%)",
        "cssVariables": {
            '--text-color': '#e0f7fa',
            '--panel-bg': '#0f172a',
            '--accent-color': '#00f2fe'
        }
    },
    {
        "id": "midnight-neon",
        "name": "Midnight Neon",
        "gradient": "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        "cssVariables": {
            '--text-color': '#e0e7ff',
            '--panel-bg': '#1e1b4b',
            '--accent-color': '#a5b4fc'
        }
    },
    {
        "id": "solar-flare",
        "name": "Solar Flare",
        "gradient": "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",
        "cssVariables": {
            '--text-color': '#fff1f2',
            '--panel-bg': '#430c17',
            '--accent-color': '#f093fb'
        }
    },
    {
        "id": "deep-space-mesh",
        "name": "Deep Space Mesh",
        "gradient": "radial-gradient(at 0% 0%, #000428 0, transparent 50%), radial-gradient(at 50% 0%, #004e92 0, transparent 50%), radial-gradient(at 100% 0%, #000428 0, transparent 50%), #000428",
        "cssVariables": {
            '--text-color': '#d1d5db',
            '--panel-bg': '#030712',
            '--accent-color': '#3b82f6'
        }
    },
    {
        "id": "mango",
        "name": "Mango",
        "gradient": "linear-gradient(to right, #355c7d 0%, #6c5b7b 33%, #c06c84 100%)",
        "cssVariables": {
            '--text-color': '#f0e8f3',
            '--text-color-strong': '#ffffff',
            '--panel-bg': '#2a3b4f',
            '--accent-color': '#c06c84'
        }
    },
    {
        "id": "windy",
        "name": "Windy",
        "gradient": "linear-gradient(to right, #bc4e9c 0%, #f80759 100%)"
    },
    {
        "id": "royal-blue",
        "name": "Royal Blue",
        "gradient": "linear-gradient(to right, #40e0d0 0%, #ff8c00 33%, #ff0080 100%)"
    },
    {
        "id": "royal-blue-petrol",
        "name": "Royal Blue + Petrol",
        "gradient": "linear-gradient(to right, #3e5151 0%, #decba4 100%)",
        "cssVariables": {
            '--text-color': '#2c3e50',
            '--text-color-strong': '#1a2530',
            '--panel-bg': '#f0f0f0',
            '--accent-color': '#3e5151'
        }
    },
    {
        "id": "copper",
        "name": "Copper",
        "gradient": "linear-gradient(to right, #11998e 0%, #38ef7d 100%)"
    },
    {
        "id": "petrol",
        "name": "Petrol",
        "gradient": "linear-gradient(to right, #108dc7 0%, #ef8e38 100%)"
    },
    {
        "id": "sky",
        "name": "Sky",
        "gradient": "linear-gradient(to right, #fc5c7d 0%, #6a82fb 100%)"
    },
    {
        "id": "sel",
        "name": "Sel",
        "gradient": "linear-gradient(to right, #fc466b 0%, #3f5efb 100%)"
    },
    {
        "id": "skyline",
        "name": "Skyline",
        "gradient": "linear-gradient(to right, #c94b4b 0%, #4b134f 100%)"
    },
    {
        "id": "dimigo",
        "name": "DIMIGO",
        "gradient": "linear-gradient(to right, #23074d 0%, #cc5333 100%)"
    },
    {
        "id": "purple-love",
        "name": "Purple Love",
        "gradient": "linear-gradient(to right, #fffbd5 0%, #b20a2c 100%)"
    },
    {
        "id": "sexy-blue",
        "name": "Sexy Blue",
        "gradient": "linear-gradient(to right, #0f0c29 0%, #302b63 33%, #24243e 100%)",
        "cssVariables": {
            '--text-color': '#c3c1d3',
            '--text-color-strong': '#e8e7f0',
            '--panel-bg': '#1a182c',
            '--accent-color': '#8c88c3'
        }
    },
    {
        "id": "blooker20",
        "name": "Blooker20",
        "gradient": "linear-gradient(to right, #00b09b 0%, #96c93d 100%)"
    },
    {
        "id": "sea-blue",
        "name": "Sea Blue",
        "gradient": "linear-gradient(to right, #d3cce3 0%, #e9e4f0 100%)"
    },
    {
        "id": "nimvelo",
        "name": "Nimvelo",
        "gradient": "linear-gradient(to right, #3c3b3f 0%, #605c3c 100%)"
    },
    {
        "id": "hazel",
        "name": "Hazel",
        "gradient": "linear-gradient(to right, #cac531 0%, #f3f9a7 100%)"
    },
    {
        "id": "noon-to-dusk",
        "name": "Noon to Dusk",
        "gradient": "linear-gradient(to right, #800080 0%, #ffc0cb 100%)"
    },
    {
        "id": "youtube",
        "name": "YouTube",
        "gradient": "linear-gradient(to right, #00f260 0%, #0575e6 100%)"
    },
    {
        "id": "cool-brown",
        "name": "Cool Brown",
        "gradient": "linear-gradient(to right, #fc4a1a 0%, #f7b733 100%)"
    },
    {
        "id": "harmonic-energy",
        "name": "Harmonic Energy",
        "gradient": "linear-gradient(to right, #e1eec3 0%, #f05053 100%)"
    },
    {
        "id": "playing-with-reds",
        "name": "Playing with Reds",
        "gradient": "linear-gradient(to right, #74ebd5 0%, #acb6e5 100%)"
    },
    {
        "id": "sunny-days",
        "name": "Sunny Days",
        "gradient": "linear-gradient(to right, #6d6027 0%, #d3cbb8 100%)"
    },
    {
        "id": "green-beach",
        "name": "Green Beach",
        "gradient": "linear-gradient(to right, #03001e 0%, #7303c0 25%, #ec38bc 50%, #fdeff9 100%)"
    },
    {
        "id": "intuitive-purple",
        "name": "Intuitive Purple",
        "gradient": "linear-gradient(to right, #667db6 0%, #0082c8 25%, #0082c8 50%, #667db6 100%)"
    },
    {
        "id": "emerald-water",
        "name": "Emerald Water",
        "gradient": "linear-gradient(to right, #ada996 0%, #f2f2f2 25%, #dbdbdb 50%, #eaeaea 100%)"
    },
    {
        "id": "lemon-twist",
        "name": "Lemon Twist",
        "gradient": "linear-gradient(to right, #e1eec3 0%, #f05053 100%)"
    },
    {
        "id": "monte-carlo",
        "name": "Monte Carlo",
        "gradient": "linear-gradient(to right, #1a2a6c 0%, #b21f1f 33%, #fdbb2d 100%)"
    },
    {
        "id": "horizon",
        "name": "Horizon",
        "gradient": "linear-gradient(to right, #22c1c3 0%, #fdbb2d 100%)"
    },
    {
        "id": "rose-water",
        "name": "Rose Water",
        "gradient": "linear-gradient(to right, #ff9966 0%, #ff5e62 100%)"
    },
    {
        "id": "frozen",
        "name": "Frozen",
        "gradient": "linear-gradient(to right, #7f00ff 0%, #e100ff 100%)"
    },
    {
        "id": "mango-pulp",
        "name": "Mango Pulp",
        "gradient": "linear-gradient(to right, #c9d6ff 0%, #e2e2e2 100%)"
    },
    {
        "id": "bloody-mary",
        "name": "Bloody Mary",
        "gradient": "linear-gradient(to right, #396afc 0%, #2948ff 100%)"
    },
    {
        "id": "aubergine",
        "name": "Aubergine",
        "gradient": "linear-gradient(to right, #d9a7c7 0%, #fffcdc 100%)"
    },
    {
        "id": "aqua-marine",
        "name": "Aqua Marine",
        "gradient": "linear-gradient(to right, #070000 0%, #4c0001 33%, #070000 100%)"
    },
    {
        "id": "sunrise",
        "name": "Sunrise",
        "gradient": "linear-gradient(to right, #000000 0%, #e5008d 33%, #ff070b 100%)"
    },
    {
        "id": "purple-paradise",
        "name": "Purple Paradise",
        "gradient": "linear-gradient(to right, #0cebeb 0%, #20e3b2 33%, #29ffc6 100%)"
    },
    {
        "id": "stripe",
        "name": "Stripe",
        "gradient": "linear-gradient(to right, #06beb6 0%, #48b1bf 100%)"
    },
    {
        "id": "sea-weed",
        "name": "Sea Weed",
        "gradient": "linear-gradient(to right, #642b73 0%, #c6426e 100%)"
    },
    {
        "id": "pinky",
        "name": "Pinky",
        "gradient": "linear-gradient(to right, #1c92d2 0%, #f2fcfe 100%)"
    },
    {
        "id": "cherry",
        "name": "Cherry",
        "gradient": "linear-gradient(to right, #000000 0%, #0f9b0f 100%)"
    },
    {
        "id": "mojito",
        "name": "Mojito",
        "gradient": "linear-gradient(to right, #36d1dc 0%, #5b86e5 100%)"
    },
    {
        "id": "juicy-orange",
        "name": "Juicy Orange",
        "gradient": "linear-gradient(to right, #cb356b 0%, #bd3f32 100%)"
    },
    {
        "id": "mirage",
        "name": "Mirage",
        "gradient": "linear-gradient(to right, #3a1c71 0%, #d76d77 33%, #ffaf7b 100%)"
    },
    {
        "id": "steel-gray",
        "name": "Steel Gray",
        "gradient": "linear-gradient(to right, #283c86 0%, #45a247 100%)"
    },
    {
        "id": "kashmir",
        "name": "Kashmir",
        "gradient": "linear-gradient(to right, #ef3b36 0%, #ffffff 100%)"
    },
    {
        "id": "electric-violet",
        "name": "Electric Violet",
        "gradient": "linear-gradient(to right, #c0392b 0%, #8e44ad 100%)"
    },
    {
        "id": "venice-blue",
        "name": "Venice Blue",
        "gradient": "linear-gradient(to right, #159957 0%, #155799 100%)"
    },
    {
        "id": "bora-bora",
        "name": "Bora Bora",
        "gradient": "linear-gradient(to right, #000046 0%, #1cb5e0 100%)"
    },    
    { "id": "moss", "name": "Moss", "gradient": "linear-gradient(to right, #007991 0%, #78ffd6 100%)" },
    { "id": "shroom-haze", "name": "Shroom Haze", "gradient": "linear-gradient(to right, #56ccf2 0%, #2f80ed 100%)" },
    { "id": "mystic", "name": "Mystic", "gradient": "linear-gradient(to right, #f2994a 0%, #f2c94c 100%)" },
    { "id": "midnight-city", "name": "Midnight City", "gradient": "linear-gradient(to right, #eb5757 0%, #000000 100%)" },
    { "id": "sea-blizz", "name": "Sea Blizz", "gradient": "linear-gradient(to right, #e44d26 0%, #f16529 100%)" },
    { "id": "opa", "name": "Opa", "gradient": "linear-gradient(to right, #4ac29a 0%, #bdfff3 100%)" },
    { "id": "titanium", "name": "Titanium", "gradient": "linear-gradient(to right, #b2fefa 0%, #0ed2f7 100%)" },
    { "id": "mantle", "name": "Mantle", "gradient": "linear-gradient(to right, #30e8bf 0%, #ff8235 100%)" },
    { "id": "dracula", "name": "Dracula", "gradient": "linear-gradient(to right, #d66d75 0%, #e29587 100%)" },
    { "id": "peach", "name": "Peach", "gradient": "linear-gradient(to right, #20002c 0%, #cbb4d4 100%)" },
    { "id": "moonrise", "name": "Moonrise", "gradient": "linear-gradient(to right, #c33764 0%, #1d2671 100%)" },
    { "id": "clouds", "name": "Clouds", "gradient": "linear-gradient(to right, #f7971e 0%, #ffd200 100%)" },
    { "id": "stellar", "name": "Stellar", "gradient": "linear-gradient(to right, #34e89e 0%, #0f3443 100%)" },
    { "id": "bourbon", "name": "Bourbon", "gradient": "linear-gradient(to right, #6190e8 0%, #a7bfe8 100%)" },
    { "id": "calm-darya", "name": "Calm Darya", "gradient": "linear-gradient(to right, #44a08d 0%, #093637 100%)" },
    { "id": "influenza", "name": "Influenza", "gradient": "linear-gradient(to right, #200122 0%, #6f0000 100%)" },
    { "id": "shrimpy", "name": "Shrimpy", "gradient": "linear-gradient(to right, #0575e6 0%, #021b79 100%)" },
    { "id": "army", "name": "Army", "gradient": "linear-gradient(to right, #4568dc 0%, #b06ab3 100%)" },
    { "id": "miaka", "name": "Miaka", "gradient": "linear-gradient(to right, #43c6ac 0%, #191654 100%)" },
    { "id": "pinot-noir", "name": "Pinot Noir", "gradient": "linear-gradient(to right, #093028 0%, #237a57 100%)" },
    { "id": "day-tripper", "name": "Day Tripper", "gradient": "linear-gradient(to right, #43c6ac 0%, #f8ffae 100%)" },
    { "id": "namn", "name": "Namn", "gradient": "linear-gradient(to right, #ffafbd 0%, #ffc3a0 100%)" },
    { "id": "blurry-beach", "name": "Blurry Beach", "gradient": "linear-gradient(to right, #f0f2f0 0%, #000c40 100%)" },
    { "id": "vasily", "name": "Vasily", "gradient": "linear-gradient(to right, #e8cbc0 0%, #636fa4 100%)" },
    { "id": "a-lost-memory", "name": "A Lost Memory", "gradient": "linear-gradient(to right, #dce35b 0%, #45b649 100%)" },
    { "id": "petrichor", "name": "Petrichor", "gradient": "linear-gradient(to right, #c0c0aa 0%, #1cefff 100%)" },
    { "id": "jonquil", "name": "Jonquil", "gradient": "linear-gradient(to right, #dbe6f6 0%, #c5796d 100%)" },
    { "id": "sirius-tamed", "name": "Sirius Tamed", "gradient": "linear-gradient(to right, #3494e6 0%, #ec6ead 100%)" },
    { "id": "kyoto", "name": "Kyoto", "gradient": "linear-gradient(to right, #67b26f 0%, #4ca2cd 100%)" },
    { "id": "misty-meadow", "name": "Misty Meadow", "gradient": "linear-gradient(to right, #f3904f 0%, #3b4371 100%)" },
    { "id": "aqualicious", "name": "Aqualicious", "gradient": "linear-gradient(to right, #ee0979 0%, #ff6a00 100%)" },
    { "id": "moor", "name": "Moor", "gradient": "linear-gradient(to right, #a770ef 0%, #cf8bf3 33%, #fdb99b 100%)" },
    { "id": "almost", "name": "Almost", "gradient": "linear-gradient(to right, #41295a 0%, #2f0743 100%)" },
    { "id": "forever-lost", "name": "Forever Lost", "gradient": "linear-gradient(to right, #f4c4f3 0%, #fc67fa 100%)" },
    { "id": "winter", "name": "Winter", "gradient": "linear-gradient(to right, #00c3ff 0%, #ffff1c 100%)" },
    { "id": "autumn", "name": "Autumn", "gradient": "linear-gradient(to right, #ff7e5f 0%, #feb47b 100%)" },
    { "id": "candy", "name": "Candy", "gradient": "linear-gradient(to right, #fffc00 0%, #ffffff 100%)" },
    { "id": "reef", "name": "Reef", "gradient": "linear-gradient(to right, #ff00cc 0%, #333399 100%)" },
    { "id": "the-strain", "name": "The Strain", "gradient": "linear-gradient(to right, #de6161 0%, #2657eb 100%)" },
    { "id": "dirty-fog", "name": "Dirty Fog", "gradient": "linear-gradient(to right, #ef32d9 0%, #89fffd 100%)" },
    { "id": "earthly", "name": "Earthly", "gradient": "linear-gradient(to right, #3a6186 0%, #89253e 100%)" },
    { "id": "virgin", "name": "Virgin", "gradient": "linear-gradient(to right, #4ecdc4 0%, #556270 100%)" },
    { "id": "ash", "name": "Ash", "gradient": "linear-gradient(to right, #a1ffce 0%, #faffd1 100%)" },
    { "id": "shadow-night", "name": "Shadow Night", "gradient": "linear-gradient(to right, #be93c5 0%, #7bc6cc 100%)" },
    { "id": "cherryblossoms", "name": "Cherryblossoms", "gradient": "linear-gradient(to right, #bdc3c7 0%, #2c3e50 100%)" },
    { "id": "parklife", "name": "Parklife", "gradient": "linear-gradient(to right, #ffd89b 0%, #19547b 100%)" },
    { "id": "dance-to-forget", "name": "Dance To Forget", "gradient": "linear-gradient(to right, #808080 0%, #3fada8 100%)" },
    { "id": "starfall", "name": "Starfall", "gradient": "linear-gradient(to right, #fceabb 0%, #f8b500 100%)" },
    { "id": "red-mist", "name": "Red Mist", "gradient": "linear-gradient(to right, #f85032 0%, #e73827 100%)" },
    { "id": "teal-love", "name": "Teal Love", "gradient": "linear-gradient(to right, #f79d00 0%, #64f38c 100%)" },
    { "id": "neon-life", "name": "Neon Life", "gradient": "linear-gradient(to right, #cb2d3e 0%, #ef473a 100%)" },
    { "id": "man-of-steel", "name": "Man of Steel", "gradient": "linear-gradient(to right, #56ab2f 0%, #a8e063 100%)" },
    { "id": "amethyst", "name": "Amethyst", "gradient": "linear-gradient(to right, #000428 0%, #004e92 100%)" },
    { "id": "cheer-up-emo-kid", "name": "Cheer Up Emo Kid", "gradient": "linear-gradient(to right, #42275a 0%, #734b6d 100%)" },
    { "id": "shore", "name": "Shore", "gradient": "linear-gradient(to right, #141e30 0%, #243b55 100%)" },
    { "id": "facebook-messenger", "name": "Facebook Messenger", "gradient": "linear-gradient(to right, #f00000 0%, #dc281e 100%)" },
    { "id": "soundcloud", "name": "SoundCloud", "gradient": "linear-gradient(to right, #2c3e50 0%, #fd746c 100%)" },
    { "id": "behongo", "name": "Behongo", "gradient": "linear-gradient(to right, #2c3e50 0%, #4ca1af 100%)" },
    { "id": "servquick", "name": "ServQuick", "gradient": "linear-gradient(to right, #e96443 0%, #904e95 100%)" },
    { "id": "friday", "name": "Friday", "gradient": "linear-gradient(to right, #0b486b 0%, #f56217 100%)" },
    { "id": "martini", "name": "Martini", "gradient": "linear-gradient(to right, #3a7bd5 0%, #3a6073 100%)" },
    { "id": "metallic-toad", "name": "Metallic Toad", "gradient": "linear-gradient(to right, #00d2ff 0%, #928dab 100%)" },
    { "id": "between-the-clouds", "name": "Between The Clouds", "gradient": "linear-gradient(to right, #2196f3 0%, #f44336 100%)" },
    { "id": "crazy-orange-i", "name": "Crazy Orange I", "gradient": "linear-gradient(to right, #ff5f6d 0%, #ffc371 100%)" },
    { "id": "hersheys", "name": "Hersheys", "gradient": "linear-gradient(to right, #ff4b1f 0%, #ff9068 100%)" },
    { "id": "talking-to-mice-elf", "name": "Talking To Mice Elf", "gradient": "linear-gradient(to right, #16bffd 0%, #cb3066 100%)" },
    { "id": "purple-bliss", "name": "Purple Bliss", "gradient": "linear-gradient(to right, #eecda3 0%, #ef629f 100%)" },
    { "id": "predawn", "name": "Predawn", "gradient": "linear-gradient(to right, #1d4350 0%, #a43931 100%)" },
    { "id": "endless-river", "name": "Endless River", "gradient": "linear-gradient(to right, #a80077 0%, #66ff00 100%)" },
    { "id": "pastel-orange-at-the-sun", "name": "Pastel Orange at the Sun", "gradient": "linear-gradient(to right, #f7ff00 0%, #db36a4 100%)" },
    { "id": "twitch", "name": "Twitch", "gradient": "linear-gradient(to right, #ff4b1f 0%, #1fddff 100%)" },
    { "id": "atlas", "name": "Atlas", "gradient": "linear-gradient(to right, #ba5370 0%, #f4e2d8 100%)" },
    { "id": "instagram", "name": "Instagram", "gradient": "linear-gradient(to right, #e0eafc 0%, #cfdef3 100%)" },
    { "id": "flickr", "name": "Flickr", "gradient": "linear-gradient(to right, #4ca1af 0%, #c4e0e5 100%)" },
    { "id": "vine", "name": "Vine", "gradient": "linear-gradient(to right, #000000 0%, #434343 100%)" },
    { "id": "turquoise-flow", "name": "Turquoise flow", "gradient": "linear-gradient(to right, #4b79a1 0%, #283e51 100%)" },
    { "id": "portrait", "name": "Portrait", "gradient": "linear-gradient(to right, #834d9b 0%, #d04ed6 100%)" },
    { "id": "virgin-america", "name": "Virgin America", "gradient": "linear-gradient(to right, #0099f7 0%, #f11712 100%)" },
    { "id": "koko-caramel", "name": "Koko Caramel", "gradient": "linear-gradient(to right, #2980b9 0%, #2c3e50 100%)" },
    { "id": "fresh-turboscent", "name": "Fresh Turboscent", "gradient": "linear-gradient(to right, #5a3f37 0%, #2c7744 100%)" },
    { "id": "green-to-dark", "name": "Green to dark", "gradient": "linear-gradient(to right, #4da0b0 0%, #d39d38 100%)" },
    { "id": "ukraine", "name": "Ukraine", "gradient": "linear-gradient(to right, #5614b0 0%, #dbd65c 100%)" },
    { "id": "curiosity-blue", "name": "Curiosity blue", "gradient": "linear-gradient(to right, #2f7336 0%, #aa3a38 100%)" },
    { "id": "dark-knight", "name": "Dark Knight", "gradient": "linear-gradient(to right, #1e3c72 0%, #2a5298 100%)" },
    { "id": "piglet", "name": "Piglet", "gradient": "linear-gradient(to right, #114357 0%, #f29492 100%)" },
    { "id": "lizard", "name": "Lizard", "gradient": "linear-gradient(to right, #fd746c 0%, #ff9068 100%)" },
    { "id": "sage-persuasion", "name": "Sage Persuasion", "gradient": "linear-gradient(to right, #eacda3 0%, #d6ae7b 100%)" },
    { "id": "between-night-and-day", "name": "Between Night and Day", "gradient": "linear-gradient(to right, #6a3093 0%, #a044ff 100%)" },
    { "id": "timber", "name": "Timber", "gradient": "linear-gradient(to right, #457fca 0%, #5691c8 100%)" },
    { "id": "passion", "name": "Passion", "gradient": "linear-gradient(to right, #b24592 0%, #f15f79 100%)" },
    { "id": "clear-sky", "name": "Clear Sky", "gradient": "linear-gradient(to right, #c02425 0%, #f0cb35 100%)" },
    { "id": "master-card", "name": "Master Card", "gradient": "linear-gradient(to right, #403a3e 0%, #be5869 100%)" },
    { "id": "back-to-earth", "name": "Back To Earth", "gradient": "linear-gradient(to right, #c2e59c 0%, #64b3f4 100%)" },
    { "id": "deep-purple", "name": "Deep Purple", "gradient": "linear-gradient(to right, #ffb75e 0%, #ed8f03 100%)" },
    { "id": "little-leaf", "name": "Little Leaf", "gradient": "linear-gradient(to right, #8e0e00 0%, #1f1c18 100%)" },
    { "id": "netflix", "name": "Netflix", "gradient": "linear-gradient(to right, #76b852 0%, #8dc26f 100%)" },
    { "id": "light-orange", "name": "Light Orange", "gradient": "linear-gradient(to right, #673ab7 0%, #512da8 100%)" },
    { "id": "green-and-blue", "name": "Green and Blue", "gradient": "linear-gradient(to right, #00c9ff 0%, #92fe9d 100%)" },
    { "id": "poncho", "name": "Poncho", "gradient": "linear-gradient(to right, #f46b45 0%, #eea849 100%)" },
    { "id": "back-to-the-future", "name": "Back to the Future", "gradient": "linear-gradient(to right, #005c97 0%, #363795 100%)" },
    { "id": "blush", "name": "Blush", "gradient": "linear-gradient(to right, #e53935 0%, #e35d5b 100%)" },
    { "id": "inbox", "name": "Inbox", "gradient": "linear-gradient(to right, #fc00ff 0%, #00dbde 100%)" },
    { "id": "purplin", "name": "Purplin", "gradient": "linear-gradient(to right, #2c3e50 0%, #3498db 100%)" },
    { "id": "pale-wood", "name": "Pale Wood", "gradient": "linear-gradient(to right, #ccccb2 0%, #757519 100%)" },
    { "id": "haikus", "name": "Haikus", "gradient": "linear-gradient(to right, #304352 0%, #d7d2cc 100%)" },
    { "id": "pizelex", "name": "Pizelex", "gradient": "linear-gradient(to right, #ee9ca7 0%, #ffdde1 100%)" },
    { "id": "joomla", "name": "Joomla", "gradient": "linear-gradient(to right, #ba8b02 0%, #181818 100%)" },
    { "id": "christmas", "name": "Christmas", "gradient": "linear-gradient(to right, #525252 0%, #3d72b4 100%)" },
    { "id": "minnesota-vikings", "name": "Minnesota Vikings", "gradient": "linear-gradient(to right, #004ff9 0%, #fff94c 100%)" },
    { "id": "miami-dolphins", "name": "Miami Dolphins", "gradient": "linear-gradient(to right, #6a9113 0%, #141517 100%)" },
    { "id": "forest", "name": "Forest", "gradient": "linear-gradient(to right, #f1f2b5 0%, #135058 100%)" },
    { "id": "nighthawk", "name": "Nighthawk", "gradient": "linear-gradient(to right, #d1913c 0%, #ffd194 100%)" },
    { "id": "superman", "name": "Superman", "gradient": "linear-gradient(to right, #7b4397 0%, #dc2430 100%)" },
    { "id": "suzy", "name": "Suzy", "gradient": "linear-gradient(to right, #8e9eab 0%, #eef2f3 100%)" },
    { "id": "dark-skies", "name": "Dark Skies", "gradient": "linear-gradient(to right, #136a8a 0%, #267871 100%)" },
    { "id": "deep-space", "name": "Deep Space", "gradient": "linear-gradient(to right, #00bf8f 0%, #001510 100%)" },
    { "id": "decent", "name": "Decent", "gradient": "linear-gradient(to right, #ff0084 0%, #33001b 100%)" },
    { "id": "colors-of-sky", "name": "Colors Of Sky", "gradient": "linear-gradient(to right, #833ab4 0%, #fd1d1d 33%, #fcb045 100%)" },
    { "id": "purple-white", "name": "Purple White", "gradient": "linear-gradient(to right, #feac5e 0%, #c779d0 33%, #4bc0c8 100%)" },
    { "id": "ali", "name": "Ali", "gradient": "linear-gradient(to right, #6441a5 0%, #2a0845 100%)" },
    { "id": "alihossein", "name": "Alihossein", "gradient": "linear-gradient(to right, #ffb347 0%, #ffcc33 100%)" },
    { "id": "shahabi", "name": "Shahabi", "gradient": "linear-gradient(to right, #43cea2 0%, #185a9d 100%)" },
    { "id": "red-ocean", "name": "Red Ocean", "gradient": "linear-gradient(to right, #ffa17f 0%, #00223e 100%)" },
    { "id": "tranquil", "name": "Tranquil", "gradient": "linear-gradient(to right, #360033 0%, #0b8793 100%)" },
    { "id": "transfile", "name": "Transfile", "gradient": "linear-gradient(to right, #948e99 0%, #2e1437 100%)" },
    { "id": "sylvia", "name": "Sylvia", "gradient": "linear-gradient(to right, #1e130c 0%, #9a8478 100%)" },
    { "id": "sweet-morning", "name": "Sweet Morning", "gradient": "linear-gradient(to right, #d38312 0%, #a83279 100%)" },
    { "id": "politics", "name": "Politics", "gradient": "linear-gradient(to right, #73c8a9 0%, #373b44 100%)" },
    { "id": "bright-vault", "name": "Bright Vault", "gradient": "linear-gradient(to right, #abbaab 0%, #ffffff 100%)" },
    { "id": "solid-vault", "name": "Solid Vault", "gradient": "linear-gradient(to right, #fdfc47 0%, #24fe41 100%)" },
    { "id": "sunset", "name": "Sunset", "gradient": "linear-gradient(to right, #83a4d4 0%, #b6fbff 100%)" },
    { "id": "grapefruit-sunset", "name": "Grapefruit Sunset", "gradient": "linear-gradient(to right, #485563 0%, #29323c 100%)" },
    { "id": "deep-sea-space", "name": "Deep Sea Space", "gradient": "linear-gradient(to right, #52c234 0%, #061700 100%)" },
    { "id": "dusk", "name": "Dusk", "gradient": "linear-gradient(to right, #fe8c00 0%, #f83600 100%)" },
    { "id": "minimal-red", "name": "Minimal Red", "gradient": "linear-gradient(to right, #00c6ff 0%, #0072ff 100%)" },
    { "id": "royal", "name": "Royal", "gradient": "linear-gradient(to right, #70e1f5 0%, #ffd194 100%)" },
    { "id": "mauve", "name": "Mauve", "gradient": "linear-gradient(to right, #556270 0%, #ff6b6b 100%)" },
    { "id": "frost", "name": "Frost", "gradient": "linear-gradient(to right, #9d50bb 0%, #6e48aa 100%)" },
    { "id": "lush", "name": "Lush", "gradient": "linear-gradient(to right, #780206 0%, #061161 100%)" },
    { "id": "firewatch", "name": "Firewatch", "gradient": "linear-gradient(to right, #b3ffab 0%, #12fff7 100%)" },
    { "id": "sherbert", "name": "Sherbert", "gradient": "linear-gradient(to right, #aaffa9 0%, #11ffbd 100%)" },
    { "id": "blood-red", "name": "Blood Red", "gradient": "linear-gradient(to right, #000000 0%, #e74c3c 100%)" },
    { "id": "sun-on-the-horizon", "name": "Sun on the Horizon", "gradient": "linear-gradient(to right, #f0c27b 0%, #4b1248 100%)" },
    { "id": "iiit-delhi", "name": "IIIT Delhi", "gradient": "linear-gradient(to right, #ff4e50 0%, #f9d423 100%)" },
    { "id": "50-shades-of-grey", "name": "50 Shades of Grey", "gradient": "linear-gradient(to right, #fbd3e9 0%, #bb377d 100%)" },
    { "id": "dania", "name": "Dania", "gradient": "linear-gradient(to right, #000000 0%, #53346d 100%)" },
    { "id": "limeade", "name": "Limeade", "gradient": "linear-gradient(to right, #606c88 0%, #3f4c6b 100%)" },
    { "id": "disco", "name": "Disco", "gradient": "linear-gradient(to right, #c9ffbf 0%, #ffafbd 100%)" },
    { "id": "love-couple", "name": "Love Couple", "gradient": "linear-gradient(to right, #649173 0%, #dbd5a4 100%)" },
    { "id": "azure-pop", "name": "Azure Pop", "gradient": "linear-gradient(to right, #b993d6 0%, #8ca6db 100%)" },
    { "id": "nepal", "name": "Nepal", "gradient": "linear-gradient(to right, #870000 0%, #190a05 100%)" },
    { "id": "cosmic-fusion", "name": "Cosmic Fusion", "gradient": "linear-gradient(to right, #00d2ff 0%, #3a7bd5 100%)" },
    { "id": "snapchat", "name": "Snapchat", "gradient": "linear-gradient(to right, #d3959b 0%, #bfe6ba 100%)" },
    { "id": "ed-s-sunset-gradient", "name": "Ed's Sunset Gradient", "gradient": "linear-gradient(to right, #dad299 0%, #b0dab9 100%)" },
    { "id": "brady-brady-fun-fun", "name": "Brady Brady Fun Fun", "gradient": "linear-gradient(to right, #e6dada 0%, #274046 100%)" },
    { "id": "black-rose", "name": "Black Rosé", "gradient": "linear-gradient(to right, #5d4157 0%, #a8caba 100%)" },
    { "id": "80-s-purple", "name": "80's Purple", "gradient": "linear-gradient(to right, #ddd6f3 0%, #faaca8 100%)" },
    { "id": "radar", "name": "Radar", "gradient": "linear-gradient(to right, #616161 0%, #9bc5c3 100%)" },
    { "id": "ibiza-sunset", "name": "Ibiza Sunset", "gradient": "linear-gradient(to right, #50c9c3 0%, #96deda 100%)" },
    { "id": "dawn", "name": "Dawn", "gradient": "linear-gradient(to right, #215f00 0%, #e4e4d9 100%)" },
    { "id": "mild", "name": "Mild", "gradient": "linear-gradient(to right, #c21500 0%, #ffc500 100%)" },
    { "id": "vice-city", "name": "Vice City", "gradient": "linear-gradient(to right, #efefbb 0%, #d4d3dd 100%)" },
    { "id": "jaipur", "name": "Jaipur", "gradient": "linear-gradient(to right, #ffeeee 0%, #ddefbb 100%)" },
    { "id": "cocoaa-ice", "name": "Cocoaa Ice", "gradient": "linear-gradient(to right, #666600 0%, #999966 100%)" },
    { "id": "easymed", "name": "EasyMed", "gradient": "linear-gradient(to right, #de6262 0%, #ffb88c 100%)" },
    { "id": "rose-colored-lenses", "name": "Rose Colored Lenses", "gradient": "linear-gradient(to right, #e9d362 0%, #333333 100%)" },
    { "id": "what-lies-beyond", "name": "What lies Beyond", "gradient": "linear-gradient(to right, #d53369 0%, #cbad6d 100%)" },
    { "id": "roseanna", "name": "Roseanna", "gradient": "linear-gradient(to right, #a73737 0%, #7a2828 100%)" },
    { "id": "honey-dew", "name": "Honey Dew", "gradient": "linear-gradient(to right, #f857a6 0%, #ff5858 100%)" },
    { "id": "under-the-lake", "name": "Under the Lake", "gradient": "linear-gradient(to right, #4b6cb7 0%, #182848 100%)" },
    { "id": "the-blue-lagoon", "name": "The Blue Lagoon", "gradient": "linear-gradient(to right, #fc354c 0%, #0abfbc 100%)" },
    { "id": "can-you-feel-the-love-tonight", "name": "Can You Feel The Love Tonight", "gradient": "linear-gradient(to right, #414d0b 0%, #727a17 100%)" },
    { "id": "very-blue", "name": "Very Blue", "gradient": "linear-gradient(to right, #e43a15 0%, #e65245 100%)" },
    { "id": "love-and-liberty", "name": "Love and Liberty", "gradient": "linear-gradient(to right, #c04848 0%, #480048 100%)" },
    { "id": "orca", "name": "Orca", "gradient": "linear-gradient(to right, #5f2c82 0%, #49a09d 100%)" },
    { "id": "venice", "name": "Venice", "gradient": "linear-gradient(to right, #ec6f66 0%, #f3a183 100%)" },
    { "id": "pacific-dream", "name": "Pacific Dream", "gradient": "linear-gradient(to right, #7474bf 0%, #348ac7 100%)" },
    { "id": "learning-and-leading", "name": "Learning and Leading", "gradient": "linear-gradient(to right, #ece9e6 0%, #ffffff 100%)" },
    { "id": "celestial", "name": "Celestial", "gradient": "linear-gradient(to right, #dae2f8 0%, #d6a4a4 100%)" },
    { "id": "purplepine", "name": "Purplepine", "gradient": "linear-gradient(to right, #ed4264 0%, #ffedbc 100%)" },
    { "id": "sha-la-la", "name": "Sha la la", "gradient": "linear-gradient(to right, #dc2424 0%, #4a569d 100%)" },
    { "id": "mini", "name": "Mini", "gradient": "linear-gradient(to right, #24c6dc 0%, #514a9d 100%)" },
    { "id": "maldives", "name": "Maldives", "gradient": "linear-gradient(to right, #283048 0%, #859398 100%)" },
    { "id": "cinnamint", "name": "Cinnamint", "gradient": "linear-gradient(to right, #3d7eaa 0%, #ffe47a 100%)" },
    { "id": "html", "name": "Html", "gradient": "linear-gradient(to right, #1cd8d2 0%, #93edc7 100%)" },
    { "id": "coal", "name": "Coal", "gradient": "linear-gradient(to right, #232526 0%, #414345 100%)" },
    { "id": "sunkist", "name": "Sunkist", "gradient": "linear-gradient(to right, #757f9a 0%, #d7dde8 100%)" },
    { "id": "blue-skies", "name": "Blue Skies", "gradient": "linear-gradient(to right, #5c258d 0%, #4389a2 100%)" },
    { "id": "chitty-chitty-bang-bang", "name": "Chitty Chitty Bang Bang", "gradient": "linear-gradient(to right, #134e5e 0%, #71b280 100%)" },
    { "id": "visions-of-grandeur", "name": "Visions of Grandeur", "gradient": "linear-gradient(to right, #2bc0e4 0%, #eaecc6 100%)" },
    { "id": "crystal-clear", "name": "Crystal Clear", "gradient": "linear-gradient(to right, #085078 0%, #85d8ce 100%)" },
    { "id": "mello", "name": "Mello", "gradient": "linear-gradient(to right, #4776e6 0%, #8e54e9 100%)" },
    { "id": "compare-now", "name": "Compare Now", "gradient": "linear-gradient(to right, #614385 0%, #516395 100%)" },
    { "id": "meridian", "name": "Meridian", "gradient": "linear-gradient(to right, #1f1c2c 0%, #928dab 100%)" },
    { "id": "relay", "name": "Relay", "gradient": "linear-gradient(to right, #16222a 0%, #3a6073 100%)" },
    { "id": "alive", "name": "Alive", "gradient": "linear-gradient(to right, #ff8008 0%, #ffc837 100%)" },
    { "id": "scooter", "name": "Scooter", "gradient": "linear-gradient(to right, #1d976c 0%, #93f9b9 100%)" },
    { "id": "terminal", "name": "Terminal", "gradient": "linear-gradient(to right, #eb3349 0%, #f45c43 100%)" },
    { "id": "telegram", "name": "Telegram", "gradient": "linear-gradient(to right, #dd5e89 0%, #f7bb97 100%)" },
    { "id": "crimson-tide", "name": "Crimson Tide", "gradient": "linear-gradient(to right, #4cb8c4 0%, #3cd3ad 100%)" },
    { "id": "socialive", "name": "Socialive", "gradient": "linear-gradient(to right, #1fa2ff 0%, #12d8fa 33%, #a6ffcb 100%)" },
    { "id": "subu", "name": "Subu", "gradient": "linear-gradient(to right, #1d2b64 0%, #f8cdda 100%)" },
    { "id": "shift", "name": "Shift", "gradient": "linear-gradient(to right, #ff512f 0%, #f09819 100%)" },
    { "id": "clot", "name": "Clot", "gradient": "linear-gradient(to right, #1a2980 0%, #26d0ce 100%)" },
    { "id": "broken-hearts", "name": "Broken Hearts", "gradient": "linear-gradient(to right, #aa076b 0%, #61045f 100%)" },
    { "id": "kimoby-is-the-new-blue", "name": "Kimoby Is The New Blue", "gradient": "linear-gradient(to right, #ff512f 0%, #dd2476 100%)" },
    { "id": "dull", "name": "Dull", "gradient": "linear-gradient(to right, #f09819 0%, #edde5d 100%)" },
    { "id": "purpink", "name": "Purpink", "gradient": "linear-gradient(to right, #403b4a 0%, #e7e9bb 100%)" },
    { "id": "orange-coral", "name": "Orange Coral", "gradient": "linear-gradient(to right, #e55d87 0%, #5fc3e4 100%)" },
    { "id": "summer", "name": "Summer", "gradient": "linear-gradient(to right, #003973 0%, #e5e5be 100%)" },
    { "id": "king-yna", "name": "King Yna", "gradient": "linear-gradient(to right, #cc95c0 0%, #dbd4b4 33%, #7aa1d2 100%)" },
    { "id": "velvet-sun", "name": "Velvet Sun", "gradient": "linear-gradient(to right, #3ca55c 0%, #b5ac49 100%)" },
    { "id": "zinc", "name": "Zinc", "gradient": "linear-gradient(to right, #348f50 0%, #56b4d3 100%)" },
    { "id": "hydrogen", "name": "Hydrogen", "gradient": "linear-gradient(to right, #da22ff 0%, #9733ee 100%)" },
    { "id": "argon", "name": "Argon", "gradient": "linear-gradient(to right, #02aab0 0%, #00cdac 100%)" },
    { "id": "lithium", "name": "Lithium", "gradient": "linear-gradient(to right, #ede574 0%, #e1f5c4 100%)" },
    { "id": "digital-water", "name": "Digital Water", "gradient": "linear-gradient(to right, #d31027 0%, #ea384d 100%)" },
    { "id": "orange-fun", "name": "Orange Fun", "gradient": "linear-gradient(to right, #603813 0%, #b29f94 100%)" },
    { "id": "rainbow-blue", "name": "Rainbow Blue", "gradient": "linear-gradient(to right, #e52d27 0%, #b31217 100%)" },
    { "id": "pink-flavour", "name": "Pink Flavour", "gradient": "linear-gradient(to right, #ff6e7f 0%, #bfe9ff 100%)" },
    { "id": "sulphur", "name": "Sulphur", "gradient": "linear-gradient(to right, #77a1d3 0%, #79cbca 33%, #e684ae 100%)" },
    { "id": "selenium", "name": "Selenium", "gradient": "linear-gradient(to right, #314755 0%, #26a0da 100%)" },
    { "id": "delicate", "name": "Delicate", "gradient": "linear-gradient(to right, #2b5876 0%, #4e4376 100%)" },
    { "id": "ohhappiness", "name": "Ohhappiness", "gradient": "linear-gradient(to right, #e65c00 0%, #f9d423 100%)" },
    { "id": "lawrencium", "name": "Lawrencium", "gradient": "linear-gradient(to right, #2193b0 0%, #6dd5ed 100%)" },
    { "id": "relaxing-red", "name": "Relaxing red", "gradient": "linear-gradient(to right, #cc2b5e 0%, #753a88 100%)" },
    { "id": "taran-tado", "name": "Taran Tado", "gradient": "linear-gradient(to right, #ec008c 0%, #fc6767 100%)" },
    { "id": "bighead", "name": "Bighead", "gradient": "linear-gradient(to right, #1488cc 0%, #2b32b2 100%)" },
    { "id": "sublime-vivid", "name": "Sublime Vivid", "gradient": "linear-gradient(to right, #00467f 0%, #a5cc82 100%)" },
    { "id": "sublime-light", "name": "Sublime Light", "gradient": "linear-gradient(to right, #076585 0%, #ffffff 100%)" },
    { "id": "pun-yeta", "name": "Pun Yeta", "gradient": "linear-gradient(to right, #bbd2c5 0%, #536976 100%)" },
    { "id": "quepal", "name": "Quepal", "gradient": "linear-gradient(to right, #b79891 0%, #94716b 100%)" },
    { "id": "sand-to-blue", "name": "Sand to Blue", "gradient": "linear-gradient(to right, #bbd2c5 0%, #536976 33%, #292e49 100%)" },
    { "id": "wedding-day-blues", "name": "Wedding Day Blues", "gradient": "linear-gradient(to right, #536976 0%, #292e49 100%)" },
    { "id": "shifter", "name": "Shifter", "gradient": "linear-gradient(to right, #acb6e5 0%, #86fde8 100%)" },
    { "id": "red-sunset", "name": "Red Sunset", "gradient": "linear-gradient(to right, #ffe259 0%, #ffa751 100%)" }
];

export const GRADIENTS = gradientsData.map(g => ({
  ...g,
  name: g.name.trim()
}));

function parseHexToRgb(hex) {
  const clean = hex.replace('#', '');
  const full = clean.length === 3 ? clean.split('').map(c => c + c).join('') : clean;
  if (full.length !== 6) return null;
  const n = parseInt(full, 16);
  if (Number.isNaN(n)) return null;
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

function rgbToHex(r, g, b) {
  return '#' + [r, g, b].map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
}

/**
 * Deriva una paleta completa (paneles, acento, texto y reloj) desde un objeto degradado
 * respetando `cssVariables` si existen o calculando contraste automático según luminancia.
 */
export function deriveGradientPalette(gradObj) {
  const vars = gradObj?.cssVariables || {};
  const hexMatches = (gradObj?.gradient || '').match(/#[0-9a-fA-F]{6}|#[0-9a-fA-F]{3}/g) || [];
  const rgbStops = hexMatches.map(parseHexToRgb).filter(Boolean);

  const lums = rgbStops.map(([r, g, b]) => (r * 299 + g * 587 + b * 114) / 1000);
  const avgLum = lums.length ? lums.reduce((a, b) => a + b, 0) / lums.length : 40;
  const isLight = avgLum > 165;

  // Color más saturado/vivo como acento por defecto si no está en cssVariables
  let derivedAccent = vars['--accent-color'] || null;
  if (!derivedAccent && rgbStops.length > 0) {
    let bestScore = -1;
    for (const [r, g, b] of rgbStops) {
      const lum = (r * 299 + g * 587 + b * 114) / 1000;
      const spread = Math.max(r, g, b) - Math.min(r, g, b);
      const contrastFit = isLight ? (255 - lum) * 0.45 : lum * 0.45;
      const score = spread + contrastFit;
      if (score > bestScore) {
        bestScore = score;
        derivedAccent = rgbToHex(r, g, b);
      }
    }
  }
  if (!derivedAccent) derivedAccent = isLight ? '#2563eb' : '#38bdf8';

  // Normalizar --panel-bg a #hex cuando venía en rgba(...)
  let panelBg = vars['--panel-bg'] || null;
  if (panelBg && panelBg.startsWith('rgb')) {
    const nums = panelBg.match(/\d+/g);
    if (nums && nums.length >= 3) {
      panelBg = rgbToHex(Number(nums[0]), Number(nums[1]), Number(nums[2]));
    }
  }
  if (!panelBg) {
    if (isLight) {
      panelBg = '#ffffff';
    } else if (rgbStops.length > 0) {
      // Oscurecer suavemente el primer color del degradado para tarjetas vidrio legibles
      const [r, g, b] = rgbStops[0];
      panelBg = rgbToHex(r * 0.35 + 8, g * 0.35 + 10, b * 0.35 + 16);
    } else {
      panelBg = '#141824';
    }
  }

  const text = vars['--text-color'] || (isLight ? '#0f172a' : '#f8fafc');
  const textSecondary = vars['--text-secondary'] || (isLight ? '#334155' : '#cbd5e1');

  return {
    panelBg,
    panelOpacity: isLight ? 0.38 : 0.28,
    panelBlur: 22,
    panelRadius: 16,
    panelShadowEnabled: false,
    panelShadowColor: '#000000',
    panelShadowBlur: 12,
    panelTextColor: text,
    panelTextSecondaryColor: textSecondary,
    accentColor: derivedAccent,
    greetingColor: text,
    nameColor: derivedAccent,
    clockColor: text,
    dateColor: textSecondary
  };
}