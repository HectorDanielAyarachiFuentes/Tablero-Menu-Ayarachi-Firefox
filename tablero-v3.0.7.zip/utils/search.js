/**
 * Gestiona la funcionalidad de la barra de búsqueda.
 * Incluye la lógica para realizar búsquedas y para el selector de motores de búsqueda y favoritos.
 */
import { $, storageGet, storageSet, isSafeWebUrl } from '../menubar/core/utils.js';
import { tiles } from '../menubar/core/tiles.js';

export function initSearch() {
    $('#searchGo').addEventListener('click', performSearch);
    $('#searchInput').addEventListener('keypress', e => e.key === 'Enter' && performSearch());

    const privacyToggle = $('#privacyToggle');
    if (privacyToggle) {
        privacyToggle.addEventListener('click', () => {
            const isActive = privacyToggle.classList.toggle('active');
            $('.search-card').classList.toggle('private-mode', isActive);
            privacyToggle.title = isActive ? 'Búsqueda privada activada' : 'Activar búsqueda privada';
        });
    }

    $('#engineSelectTrigger').addEventListener('click', () => {
        const list = $('#engineSelectList');
        const isHidden = list.hidden;
        list.hidden = !isHidden;
        $('#engineSelectTrigger').setAttribute('aria-expanded', String(isHidden));
        $('.custom-select-wrapper').classList.toggle('open', isHidden);
    });

    $('#engineSelectList').addEventListener('click', handleEngineSelect);
    
    // Fallback for search icon (replaces removed inline onerror)
    const engineIcon = $('#selectedEngineIcon');
    if (engineIcon) {
        engineIcon.addEventListener('error', () => {
            engineIcon.src = 'icons/icon.svg';
        }, { once: true });
    }

    document.addEventListener('click', (e) => {
        if (!$('.custom-select-wrapper').contains(e.target)) {
            $('#engineSelectList').hidden = true;
            $('#engineSelectTrigger').setAttribute('aria-expanded', 'false');
            $('.custom-select-wrapper').classList.remove('open');
        }
    });
}

async function performSearch() {
    const q = $('#searchInput').value.trim();
    if (q) {
        const isPrivate = $('#privacyToggle')?.classList.contains('active');
        const { engine } = await storageGet(['engine']);
        const activeEngine = isPrivate ? 'startpage' : (engine || 'google');
        window.open(buildSearchUrl(activeEngine, q), '_blank', 'noopener,noreferrer');
    }
}

function buildSearchUrl(engine, q) {
    const enc = encodeURIComponent(q);
    const urls = {
        google: 'https://www.google.com/search?q=',
        duck: 'https://duckduckgo.com/?q=',
        startpage: 'https://www.startpage.com/do/search?q=',
        brave: 'https://search.brave.com/search?q=',
        bing: 'https://www.bing.com/search?q=',
        youtube: 'https://www.youtube.com/results?search_query=',
        wiki: 'https://es.wikipedia.org/w/index.php?search=',
        ecosia: 'https://www.ecosia.org/search?q='
    };
    return (urls[engine] || urls.google) + enc;
}

function updateSearchIcon(engine) {
    const domains = {
        google: 'google.com', duck: 'duckduckgo.com', bing: 'bing.com',
        youtube: 'youtube.com', wiki: 'wikipedia.org', ecosia: 'ecosia.org',
        startpage: 'startpage.com', brave: 'brave.com'
    };
    if (domains[engine]) {
        $('#selectedEngineIcon').src = `https://t3.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://${domains[engine]}&size=32`;
    }
}

export async function renderFavoritesInSelect() {
    const engineSelectList = $('#engineSelectList');
    engineSelectList.textContent = '';
    const { engine: currentEngine } = await storageGet(['engine']);

    const engines = [
        { value: 'google', text: 'Google' }, 
        { value: 'duck', text: 'DuckDuckGo' },
        { value: 'startpage', text: 'Startpage (Privado)' },
        { value: 'brave', text: 'Brave Search' },
        { value: 'bing', text: 'Bing' }, 
        { value: 'youtube', text: 'YouTube' },
        { value: 'wiki', text: 'Wikipedia' }, 
        { value: 'ecosia', text: 'Ecosia' },
    ];

    const createOption = (item) => {
        const option = document.createElement('div');
        option.className = 'option';
        option.dataset.value = item.value;
        if (item.url) option.dataset.url = item.url;
        const domain = item.url ? new URL(item.url).hostname : `${item.value}.com`;
        const img = document.createElement('img');
        img.src = `https://t3.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=http://${domain}&size=32`;
        img.addEventListener('error', () => { img.src = 'icons/icon.svg'; }, { once: true });
        img.alt = '';
        const span = document.createElement('span');
        span.textContent = item.text;
        option.appendChild(img);
        option.appendChild(span);
        engineSelectList.appendChild(option);
    };

    engines.forEach(createOption);
    tiles.filter(t => t.favorite && isSafeWebUrl(t.url)).forEach(tile => createOption({
        value: `favorite-${tile.url}`, text: `⭐ ${tile.name}`, url: tile.url
    }));

    const currentEngineData = engines.find(e => e.value === currentEngine);
    if (currentEngineData) $('#selectedEngineName').textContent = currentEngineData.text;
    updateSearchIcon(currentEngine);
}

async function handleEngineSelect(e) {
    const option = e.target.closest('.option');
    if (!option) return;
    const selectedValue = option.dataset.value;
    if (selectedValue.startsWith('favorite-')) {
        if (isSafeWebUrl(option.dataset.url)) {
            window.open(option.dataset.url, '_blank', 'noopener,noreferrer');
        }
    } else {
        await storageSet({ engine: selectedValue });
        updateSearchIcon(selectedValue);
        $('#selectedEngineName').textContent = option.querySelector('span').textContent;
    }
    $('#engineSelectList').hidden = true;
    $('#engineSelectTrigger').setAttribute('aria-expanded', 'false');
    $('.custom-select-wrapper').classList.remove('open');
}